import type { Metadata } from "next";

export const siteConfig: Metadata = {
  title: "Not Zeno — Developer & Builder",
  description: "Not Zeno — developer building web apps, Discord systems, automation and interactive experiences.",
  keywords: ["Not Zeno", "developer", "TypeScript", "Next.js", "Discord", "automation", "web development"],
  authors: [{ name: "Not Zeno" }],
};
