"use client";
import { useState } from "react";
import Link from "next/link";

const links = [["About", "#about"], ["Skills", "#skills"], ["Work", "#projects"], ["Contact", "#contact"]];
export const Navbar = () => {
  const [open, setOpen] = useState(false);
  return <header className="fixed left-0 right-0 top-0 z-50 px-4 pt-4 sm:px-6"><nav className="mx-auto flex max-w-5xl items-center justify-between rounded-full border border-white/8 bg-black/65 px-5 py-3 backdrop-blur-xl">
    <Link href="#home" className="text-sm font-semibold tracking-tight">NZ<span className="text-zinc-600">.</span></Link>
    <div className="hidden items-center gap-7 text-xs text-zinc-500 md:flex">{links.map(([n,h]) => <Link key={h} href={h} className="transition hover:text-white">{n}</Link>)}</div>
    <Link href="#contact" className="hidden rounded-full bg-white px-4 py-2 text-xs font-medium text-black md:block">Let&apos;s talk</Link>
    <button aria-label="Toggle menu" onClick={() => setOpen(!open)} className="text-sm text-zinc-300 md:hidden">{open ? "×" : "☰"}</button>
    {open && <div className="absolute left-3 right-3 top-14 rounded-2xl border border-white/10 bg-[#0a0a0a] p-4 md:hidden">{links.map(([n,h]) => <Link onClick={() => setOpen(false)} key={h} href={h} className="block border-b border-white/5 py-3 text-sm text-zinc-400">{n}</Link>)}</div>}
  </nav></header>;
};
