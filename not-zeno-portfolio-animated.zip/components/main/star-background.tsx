export const StarsCanvas = () => null;
export const StarBackground = () => null;
