export const Footer = () => null;
