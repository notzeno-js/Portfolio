"use client";

import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { FaDiscord, FaGithub, FaInstagram } from "react-icons/fa";
import { FiArrowDown, FiArrowUpRight, FiCheck, FiCopy, FiTerminal, FiZap } from "react-icons/fi";

const projects = [
  { name: "ZEVON", type: "Discord security ecosystem", desc: "A scalable moderation and security system focused on speed, automation, logging and clean operator UX.", tags: ["Node.js", "Discord.js", "PostgreSQL"], number: "01" },
  { name: "NEXUS", type: "Web platform", desc: "A dark, responsive product interface built around motion, useful interactions and a deliberately minimal visual system.", tags: ["Next.js", "React", "Tailwind"], number: "02" },
  { name: "LAB / 03", type: "Experiments & systems", desc: "Small tools, automations, APIs and backend experiments used to explore better ways of building software.", tags: ["APIs", "Redis", "Automation"], number: "03" },
];

const skills = ["TypeScript", "JavaScript", "React", "Next.js", "Node.js", "Discord.js", "PostgreSQL", "Redis", "Tailwind", "Git", "Linux", "REST APIs"];

function Reveal({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  return <motion.div className={className} initial={{ opacity: 0, y: 32, filter: "blur(8px)" }} whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }} viewport={{ once: true, amount: 0.15 }} transition={{ duration: .7, delay, ease: [0.22, 1, .36, 1] }}>{children}</motion.div>;
}

function TiltCard({ children }: { children: React.ReactNode }) {
  const x = useMotionValue(0); const y = useMotionValue(0);
  const rx = useTransform(useSpring(y, { stiffness: 180, damping: 22 }), [-150, 150], [5, -5]);
  const ry = useTransform(useSpring(x, { stiffness: 180, damping: 22 }), [-150, 150], [-5, 5]);
  return <motion.div style={{ rotateX: rx, rotateY: ry, transformPerspective: 1000 }} onMouseMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); x.set(e.clientX - r.left - r.width / 2); y.set(e.clientY - r.top - r.height / 2); }} onMouseLeave={() => { x.set(0); y.set(0); }} className="h-full">{children}</motion.div>;
}

export default function Home() {
  const [copied, setCopied] = useState(false);
  const [command, setCommand] = useState("whoami");
  const [time, setTime] = useState(0);
  const mouseX = useMotionValue(-500), mouseY = useMotionValue(-500);
  const glowX = useSpring(mouseX, { stiffness: 90, damping: 20 }); const glowY = useSpring(mouseY, { stiffness: 90, damping: 20 });

  useEffect(() => { const move = (e: MouseEvent) => { mouseX.set(e.clientX); mouseY.set(e.clientY); }; window.addEventListener("mousemove", move); const id = setInterval(() => setTime(t => t + 1), 1000); return () => { window.removeEventListener("mousemove", move); clearInterval(id); }; }, [mouseX, mouseY]);

  const output = command === "whoami" ? "not zeno — developer / builder" : command === "status" ? "online · building something new" : command === "stack" ? "ts · react · next · node · discord" : command === "uptime" ? `${Math.floor(time / 60).toString().padStart(2, "0")}m ${String(time % 60).padStart(2, "0")}s · still shipping` : "command not found — try whoami, status, stack, uptime";
  const copyDiscord = async () => { await navigator.clipboard?.writeText("Not Zeno"); setCopied(true); setTimeout(() => setCopied(false), 1500); };

  return <main className="min-h-screen overflow-hidden text-zinc-100">
    <motion.div className="pointer-events-none fixed z-50 hidden h-80 w-80 rounded-full bg-white/[.045] blur-3xl md:block" style={{ left: glowX, top: glowY, translateX: "-50%", translateY: "-50%" }} />
    <motion.div className="fixed left-0 top-0 z-[60] h-[2px] origin-left bg-white" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: 1.4, ease: "easeOut" }} />

    <nav className="fixed top-0 z-40 w-full border-b border-white/[.06] bg-[#050505]/65 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
        <a href="#home" className="group font-mono text-sm font-bold tracking-tight">NZ<span className="text-zinc-600 transition group-hover:text-white">.</span></a>
        <div className="hidden items-center gap-7 text-xs text-zinc-500 sm:flex">{[["about", "About"], ["projects", "Work"], ["skills", "Stack"], ["contact", "Contact"]].map(([id, label]) => <a key={id} href={`#${id}`} className="transition hover:text-white">{label}</a>)}</div>
        <a href="#contact" className="rounded-full border border-white/10 px-4 py-2 text-xs text-zinc-300 transition hover:border-white/25 hover:bg-white/[.06]">Let&apos;s build</a>
      </div>
    </nav>

    <section id="home" className="relative mx-auto flex min-h-screen max-w-7xl items-center px-6 pb-20 pt-32 lg:px-10">
      <div className="absolute inset-0 -z-10 grid-bg opacity-40" />
      <div className="grid w-full gap-16 lg:grid-cols-[1.1fr_.9fr] lg:items-center">
        <div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7 }} className="mb-7 inline-flex items-center gap-3 rounded-full border border-white/10 bg-white/[.035] px-4 py-2 text-xs text-zinc-400 backdrop-blur"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> available for interesting builds</motion.div>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .25 }} className="mb-4 font-mono text-xs uppercase tracking-[.35em] text-zinc-600">developer / systems / creative code</motion.p>
          <motion.h1 initial={{ opacity: 0, y: 35 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .08, duration: .9, ease: [0.22, 1, .36, 1] }} className="max-w-5xl text-6xl font-semibold tracking-[-.07em] sm:text-8xl lg:text-[7.4rem] leading-[.88]">I build<br /><span className="gradient-text">digital systems.</span></motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .25 }} className="mt-8 max-w-2xl text-base leading-7 text-zinc-400 sm:text-lg">I&apos;m <span className="text-zinc-100">Not Zeno</span> — a developer focused on web apps, Discord systems, automation and interfaces that feel considered instead of copied.</motion.p>
          <div className="mt-9 flex flex-wrap gap-3"><motion.a whileHover={{ y: -3 }} whileTap={{ scale: .97 }} href="#projects" className="rounded-full bg-white px-5 py-3 text-sm font-medium text-black shadow-[0_0_40px_rgba(255,255,255,.08)]">Explore work <FiArrowUpRight className="ml-2 inline" /></motion.a><motion.button whileHover={{ y: -3 }} whileTap={{ scale: .97 }} onClick={copyDiscord} className="rounded-full border border-white/10 bg-white/[.03] px-5 py-3 text-sm text-zinc-200">{copied ? <><FiCheck className="mr-2 inline text-emerald-400" /> copied</> : <><FiCopy className="mr-2 inline" /> Discord: Not Zeno</>}</motion.button></div>
          <div className="mt-12 flex items-center gap-5 text-zinc-600"><a href="https://github.com" target="_blank" rel="noreferrer" className="transition hover:scale-110 hover:text-white"><FaGithub size={19} /></a><a href="#contact" className="transition hover:scale-110 hover:text-white"><FaDiscord size={20} /></a><a href="https://instagram.com" target="_blank" rel="noreferrer" className="transition hover:scale-110 hover:text-white"><FaInstagram size={19} /></a></div>
        </div>

        <TiltCard><motion.div initial={{ opacity: 0, scale: .92, rotate: 2 }} animate={{ opacity: 1, scale: 1, rotate: 0 }} transition={{ delay: .2, duration: 1 }} className="relative mx-auto max-w-lg"><div className="orb orb-one" /><div className="orb orb-two" /><div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-[#080809]/90 shadow-2xl shadow-black/70 backdrop-blur-xl"><div className="scanline" /><div className="flex items-center gap-2 border-b border-white/10 px-5 py-4 text-xs text-zinc-500"><FiTerminal /> zeno@localhost <span className="ml-auto">interactive</span></div><div className="min-h-[360px] p-6 font-mono text-sm leading-8"><div><span className="text-zinc-700">01</span> <span className="text-zinc-500">$</span> <input aria-label="Terminal command" value={command} onChange={e => setCommand(e.target.value)} className="w-[calc(100%-45px)] bg-transparent text-zinc-100 outline-none" /></div><motion.div key={output} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="mt-3 min-h-7 whitespace-pre-wrap text-zinc-400">{output}</motion.div><div className="mt-8 grid grid-cols-2 gap-3 font-sans text-xs">{[["FOCUS", "web + systems"], ["MODE", "ship > talk"], ["STACK", "typescript"], ["STATUS", "building"]].map(([a,b], i) => <motion.div key={a} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .45 + i * .08 }} className="terminal-card rounded-2xl border border-white/8 bg-white/[.025] p-4"><p className="text-zinc-600">{a}</p><p className="mt-1 text-zinc-200">{b}</p></motion.div>)}</div></div></div></motion.div></TiltCard>
      </div>
      <motion.a href="#about" animate={{ y: [0, 7, 0] }} transition={{ repeat: Infinity, duration: 2 }} className="absolute bottom-8 left-1/2 -translate-x-1/2 text-zinc-600 hover:text-white"><FiArrowDown /></motion.a>
    </section>

    <div className="marquee border-y border-white/[.06] bg-white/[.015] py-4"><div className="marquee-track">{[...skills, ...skills].map((s, i) => <span key={`${s}-${i}`}><FiZap className="inline text-zinc-700" /> {s}</span>)}</div></div>

    <section id="about" className="mx-auto max-w-7xl px-6 py-32 lg:px-10"><div className="grid gap-12 lg:grid-cols-[.7fr_1.3fr]"><Reveal><p className="text-xs uppercase tracking-[.3em] text-zinc-600">01 / about</p><h2 className="mt-4 text-5xl font-semibold tracking-[-.05em]">Quietly building.<br /><span className="text-zinc-500">Constantly learning.</span></h2></Reveal><div className="grid gap-5 sm:grid-cols-2"><Reveal delay={.08}><p className="glass-card p-7 leading-7 text-zinc-400">I like taking an idea from a rough thought to a working product. The fun part is the tiny details — interactions, performance, architecture and making the whole thing feel intentional.</p></Reveal><Reveal delay={.16}><p className="glass-card p-7 leading-7 text-zinc-400">My projects usually sit between software and design: useful tools, bots, dashboards, experiments and systems that solve actual problems.</p></Reveal></div></div></section>

    <section id="skills" className="border-y border-white/[.06] bg-white/[.012]"><div className="mx-auto max-w-7xl px-6 py-28 lg:px-10"><Reveal><p className="text-xs uppercase tracking-[.3em] text-zinc-600">02 / toolkit</p><div className="mt-9 flex flex-wrap gap-3">{skills.map((s, i) => <motion.span key={s} initial={{ opacity: 0, scale: .8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * .035 }} whileHover={{ y: -4, scale: 1.04 }} className="rounded-full border border-white/8 bg-white/[.025] px-4 py-2.5 text-sm text-zinc-400 hover:border-white/20 hover:text-white">{s}</motion.span>)}</div></Reveal></div></section>

    <section id="projects" className="mx-auto max-w-7xl px-6 py-32 lg:px-10"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><Reveal><p className="text-xs uppercase tracking-[.3em] text-zinc-600">03 / selected work</p><h2 className="mt-4 text-5xl font-semibold tracking-[-.05em]">Things I&apos;ve been building.</h2></Reveal><span className="text-sm text-zinc-600">03 projects · always iterating</span></div><div className="mt-12 grid gap-5 lg:grid-cols-3">{projects.map((p, i) => <Reveal key={p.name} delay={i * .1}><TiltCard><motion.article whileHover={{ y: -7 }} className="group relative h-full overflow-hidden rounded-[2rem] border border-white/8 bg-white/[.025] p-7 transition-colors hover:border-white/20 hover:bg-white/[.045]"><div className="project-glow" /><div className="relative flex items-center justify-between"><span className="font-mono text-xs text-zinc-600">{p.number}</span><FiArrowUpRight className="text-zinc-600 transition duration-300 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-white" /></div><p className="relative mt-20 text-xs uppercase tracking-[.2em] text-zinc-600">{p.type}</p><h3 className="relative mt-2 text-3xl font-semibold tracking-tight">{p.name}</h3><p className="relative mt-4 min-h-24 text-sm leading-6 text-zinc-500">{p.desc}</p><div className="relative mt-7 flex flex-wrap gap-2">{p.tags.map(t => <span key={t} className="rounded-full bg-white/[.04] px-3 py-1 text-[11px] text-zinc-500">{t}</span>)}</div></motion.article></TiltCard></Reveal>)}</div></section>

    <section id="contact" className="mx-auto max-w-7xl px-6 pb-28 lg:px-10"><Reveal><div className="relative overflow-hidden rounded-[2.3rem] border border-white/10 bg-white/[.035] p-8 sm:p-14"><div className="contact-grid absolute inset-0" /><div className="relative"><p className="text-xs uppercase tracking-[.3em] text-zinc-600">04 / contact</p><div className="mt-8 flex flex-col justify-between gap-10 md:flex-row md:items-end"><div><h2 className="max-w-2xl text-5xl font-semibold tracking-[-.05em] sm:text-6xl">Got an idea?<br /><span className="gradient-text">Let&apos;s make it real.</span></h2><p className="mt-5 text-zinc-500">Projects, collaborations or just a good tech conversation.</p></div><a href="mailto:hello@example.com" className="w-fit rounded-full bg-white px-6 py-3 text-sm font-medium text-black transition hover:-translate-y-1 hover:bg-zinc-200">Say hello <FiArrowUpRight className="ml-2 inline" /></a></div></div></div></Reveal></section>

    <footer className="border-t border-white/[.06] px-6 py-8 text-xs text-zinc-600"><div className="mx-auto flex max-w-7xl justify-between"><span>© 2026 Not Zeno</span><span>built with intent.</span></div></footer>
  </main>;
}
