import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import type { PropsWithChildren } from "react";
import { Navbar } from "@/components/main/navbar";
import { siteConfig } from "@/config";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });
export const viewport: Viewport = { themeColor: "#050505" };
export const metadata: Metadata = siteConfig;
export default function RootLayout({ children }: PropsWithChildren) {
  return <html lang="en"><body className={inter.className}><Navbar />{children}</body></html>;
}
